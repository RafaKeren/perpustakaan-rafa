package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LoanRecord
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditRecordDialog(
    recordToEdit: LoanRecord? = null,
    defaultOfficer: String,
    knownOfficers: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (
        bookId: String,
        bookTitle: String,
        borrowerId: String,
        borrowerName: String,
        borrowerGrade: String,
        borrowOfficer: String,
        borrowDate: String,
        dueDate: String,
        notes: String
    ) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    var bookId by remember { mutableStateOf(recordToEdit?.bookId ?: "") }
    var bookTitle by remember { mutableStateOf(recordToEdit?.bookTitle ?: "") }
    var borrowerId by remember { mutableStateOf(recordToEdit?.borrowerId ?: "") }
    var borrowerName by remember { mutableStateOf(recordToEdit?.borrowerName ?: "") }
    var borrowerGrade by remember { mutableStateOf(recordToEdit?.borrowerGrade ?: "") }
    var borrowOfficer by remember {
        mutableStateOf(recordToEdit?.borrowOfficer ?: defaultOfficer.ifBlank { "Mrs. Sarah Jenkins" })
    }
    var borrowDate by remember {
        mutableStateOf(recordToEdit?.borrowDate ?: dateFormat.format(Date()))
    }
    var dueDate by remember {
        mutableStateOf(
            recordToEdit?.dueDate ?: run {
                val c = Calendar.getInstance()
                c.add(Calendar.DAY_OF_YEAR, 14) // default 14-day loan
                dateFormat.format(c.time)
            }
        )
    }
    var notes by remember { mutableStateOf(recordToEdit?.notes ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun addDaysToDueDate(days: Int) {
        val c = Calendar.getInstance()
        try {
            val parsedBorrow = dateFormat.parse(borrowDate)
            if (parsedBorrow != null) {
                c.time = parsedBorrow
            }
        } catch (_: Exception) {}
        c.add(Calendar.DAY_OF_YEAR, days)
        dueDate = dateFormat.format(c.time)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (recordToEdit == null) "New Book Loan" else "Edit Loan Record",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                // Book Details
                Text(
                    text = "BOOK INFORMATION",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = bookTitle,
                    onValueChange = { bookTitle = it },
                    label = { Text("Book Title *") },
                    placeholder = { Text("e.g., To Kill a Mockingbird") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_book_title")
                )

                OutlinedTextField(
                    value = bookId,
                    onValueChange = { bookId = it },
                    label = { Text("Book ID / Barcode *") },
                    placeholder = { Text("e.g., BK-1042") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_book_id")
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Borrower Details
                Text(
                    text = "BORROWER (STUDENT / STAFF)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = borrowerName,
                    onValueChange = { borrowerName = it },
                    label = { Text("Borrower Full Name *") },
                    placeholder = { Text("e.g., Alex Johnson") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_borrower_name")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = borrowerId,
                        onValueChange = { borrowerId = it },
                        label = { Text("Student / ID *") },
                        placeholder = { Text("STD-2024-055") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_borrower_id")
                    )

                    OutlinedTextField(
                        value = borrowerGrade,
                        onValueChange = { borrowerGrade = it },
                        label = { Text("Class / Role") },
                        placeholder = { Text("10-B") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_borrower_grade")
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Officer and Dates
                Text(
                    text = "DUTY OFFICER & TIMELINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = borrowOfficer,
                    onValueChange = { borrowOfficer = it },
                    label = { Text("Borrow Officer Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_borrow_officer")
                )

                // Quick chips for known officers
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    knownOfficers.forEach { officer ->
                        FilterChip(
                            selected = borrowOfficer.trim().equals(officer.trim(), ignoreCase = true),
                            onClick = { borrowOfficer = officer },
                            label = { Text(officer, fontSize = 11.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = borrowDate,
                        onValueChange = { borrowDate = it },
                        label = { Text("Borrow Date") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_borrow_date")
                    )

                    OutlinedTextField(
                        value = dueDate,
                        onValueChange = { dueDate = it },
                        label = { Text("Due Date") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_due_date")
                    )
                }

                // Due date quick buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(7 to "+7 Days", 14 to "+14 Days", 30 to "+30 Days").forEach { (days, label) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { addDaysToDueDate(days) }
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Condition") },
                    placeholder = { Text("e.g., Pristine condition, has CD") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("input_notes")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (bookTitle.isBlank() || bookId.isBlank() || borrowerName.isBlank() || borrowerId.isBlank() || borrowOfficer.isBlank()) {
                        errorMessage = "Please fill in all required fields (marked with *)."
                    } else {
                        onConfirm(
                            bookId,
                            bookTitle,
                            borrowerId,
                            borrowerName,
                            borrowerGrade,
                            borrowOfficer,
                            borrowDate,
                            dueDate,
                            notes
                        )
                    }
                },
                modifier = Modifier.testTag("save_loan_button")
            ) {
                Text("Save Entry")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
