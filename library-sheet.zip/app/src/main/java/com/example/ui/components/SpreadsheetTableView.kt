package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TableRows
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LoanRecord
import com.example.data.LoanStatus
import com.example.ui.theme.SheetBorder
import com.example.ui.theme.SheetHeaderBg
import com.example.ui.theme.SheetZebraBg
import com.example.ui.theme.StatusBorrowedBg
import com.example.ui.theme.StatusBorrowedText
import com.example.ui.theme.StatusOverdueBg
import com.example.ui.theme.StatusOverdueText
import com.example.ui.theme.StatusReturnedBg
import com.example.ui.theme.StatusReturnedText
import com.example.ui.theme.Teal40

// Column width specifications for the spreadsheet grid
private val ColRowWidth = 48.dp
private val ColStatusWidth = 100.dp
private val ColBookWidth = 200.dp
private val ColBorrowerWidth = 190.dp
private val ColBorrowEventWidth = 170.dp
private val ColDueWidth = 105.dp
private val ColReturnEventWidth = 170.dp
private val ColActionsWidth = 140.dp

private val TotalTableWidth = ColRowWidth + ColStatusWidth + ColBookWidth +
    ColBorrowerWidth + ColBorrowEventWidth + ColDueWidth + ColReturnEventWidth + ColActionsWidth

@Composable
fun SpreadsheetTableView(
    records: List<LoanRecord>,
    onSelectRecord: (LoanRecord) -> Unit,
    onReturnClick: (LoanRecord) -> Unit,
    onEditClick: (LoanRecord) -> Unit,
    onDeleteClick: (LoanRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()

    if (records.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.TableRows,
                    contentDescription = null,
                    modifier = Modifier.size(54.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No matching spreadsheet records",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Try adjusting your search query or filter chips",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .horizontalScroll(horizontalScrollState)
    ) {
        Column(
            modifier = Modifier.width(TotalTableWidth)
        ) {
            // Spreadsheet Table Header
            SpreadsheetTableHeader()

            // Spreadsheet Rows List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                itemsIndexed(records, key = { _, item -> item.id }) { index, record ->
                    val isZebra = index % 2 == 1
                    val rowBg = if (isZebra) SheetZebraBg else MaterialTheme.colorScheme.surface

                    SpreadsheetTableRow(
                        rowNumber = index + 1,
                        record = record,
                        backgroundColor = rowBg,
                        onRowClick = { onSelectRecord(record) },
                        onReturnClick = { onReturnClick(record) },
                        onEditClick = { onEditClick(record) },
                        onDeleteClick = { onDeleteClick(record) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SpreadsheetTableHeader() {
    Surface(
        color = SheetHeaderBg,
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = SheetBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderCell(text = "#", width = ColRowWidth, textAlign = TextAlign.Center)
            HeaderDivider()
            HeaderCell(text = "STATUS", width = ColStatusWidth)
            HeaderDivider()
            HeaderCell(text = "BOOK & ID", width = ColBookWidth)
            HeaderDivider()
            HeaderCell(text = "BORROWER & ID", width = ColBorrowerWidth)
            HeaderDivider()
            HeaderCell(text = "BORROWED (WHEN/WHO)", width = ColBorrowEventWidth)
            HeaderDivider()
            HeaderCell(text = "DUE DATE", width = ColDueWidth)
            HeaderDivider()
            HeaderCell(text = "RETURNED (WHEN/WHO)", width = ColReturnEventWidth)
            HeaderDivider()
            HeaderCell(text = "ACTIONS", width = ColActionsWidth, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun HeaderCell(
    text: String,
    width: Dp,
    textAlign: TextAlign = TextAlign.Start
) {
    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 8.dp),
        contentAlignment = when (textAlign) {
            TextAlign.Center -> Alignment.Center
            TextAlign.End -> Alignment.CenterEnd
            else -> Alignment.CenterStart
        }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = Teal40,
            letterSpacing = 0.6.sp,
            textAlign = textAlign,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun HeaderDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(24.dp)
            .background(SheetBorder)
    )
}

@Composable
private fun CellDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(68.dp)
            .background(SheetBorder.copy(alpha = 0.7f))
    )
}

@Composable
private fun SpreadsheetTableRow(
    rowNumber: Int,
    record: LoanRecord,
    backgroundColor: Color,
    onRowClick: () -> Unit,
    onReturnClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val status = record.getEffectiveStatus()

    Surface(
        color = backgroundColor,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRowClick() }
            .border(width = 0.5.dp, color = SheetBorder)
            .testTag("spreadsheet_row_${record.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Row #
            Box(
                modifier = Modifier
                    .width(ColRowWidth)
                    .padding(horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rowNumber.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    fontFamily = FontFamily.Monospace
                )
            }

            CellDivider()

            // Status Pill
            Box(
                modifier = Modifier
                    .width(ColStatusWidth)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                StatusBadge(status = status)
            }

            CellDivider()

            // Book & ID
            Column(
                modifier = Modifier
                    .width(ColBookWidth)
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = record.bookTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = record.bookId,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            CellDivider()

            // Borrower & Student ID
            Column(
                modifier = Modifier
                    .width(ColBorrowerWidth)
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = record.borrowerName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = record.borrowerId,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    if (record.borrowerGrade.isNotBlank()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${record.borrowerGrade})",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            CellDivider()

            // Borrowed When / By Officer
            Column(
                modifier = Modifier
                    .width(ColBorrowEventWidth)
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = record.borrowDate,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "By: ${record.borrowOfficer}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            CellDivider()

            // Due Date
            Column(
                modifier = Modifier
                    .width(ColDueWidth)
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = record.dueDate,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (status == LoanStatus.OVERDUE) FontWeight.Bold else FontWeight.Normal,
                    color = if (status == LoanStatus.OVERDUE) StatusOverdueText else MaterialTheme.colorScheme.onSurface,
                    fontFamily = FontFamily.Monospace
                )
            }

            CellDivider()

            // Returned When / By Officer
            Column(
                modifier = Modifier
                    .width(ColReturnEventWidth)
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                if (record.isReturned && record.returnDate != null) {
                    Text(
                        text = record.returnDate,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = StatusReturnedText,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "To: ${record.returnOfficer ?: "Staff"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusReturnedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Text(
                        text = "— Active Loan —",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }

            CellDivider()

            // Actions
            Row(
                modifier = Modifier
                    .width(ColActionsWidth)
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!record.isReturned) {
                    ElevatedButton(
                        onClick = onReturnClick,
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = StatusReturnedBg,
                            contentColor = StatusReturnedText
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("table_return_btn_${record.id}")
                    ) {
                        Text(
                            text = "Return",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                IconButton(
                    onClick = onEditClick,
                    modifier = Modifier.size(32.dp).testTag("table_edit_btn_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit record",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(32.dp).testTag("table_delete_btn_${record.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete record",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: LoanStatus) {
    val (bgColor, textColor, label) = when (status) {
        LoanStatus.BORROWED -> Triple(StatusBorrowedBg, StatusBorrowedText, "Borrowed")
        LoanStatus.OVERDUE -> Triple(StatusOverdueBg, StatusOverdueText, "Overdue")
        LoanStatus.RETURNED -> Triple(StatusReturnedBg, StatusReturnedText, "Returned")
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
