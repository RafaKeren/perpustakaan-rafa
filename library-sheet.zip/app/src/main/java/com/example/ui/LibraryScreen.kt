package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.LocalLibrary
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.LoanRecord
import com.example.ui.components.AddEditRecordDialog
import com.example.ui.components.ChangeOfficerDialog
import com.example.ui.components.CirculationCardView
import com.example.ui.components.RecordDetailDialog
import com.example.ui.components.ReturnBookDialog
import com.example.ui.components.SpreadsheetHeaderStats
import com.example.ui.components.SpreadsheetTableView
import com.example.ui.theme.Teal40
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val records by viewModel.filteredRecords.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val currentOfficer by viewModel.currentOfficer.collectAsStateWithLifecycle()
    val isSpreadsheetView by viewModel.isSpreadsheetView.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()

    // Dialog & UI states
    var showAddDialog by remember { mutableStateOf(false) }
    var recordToEdit by remember { mutableStateOf<LoanRecord?>(null) }
    var recordToReturn by remember { mutableStateOf<LoanRecord?>(null) }
    var recordToInspect by remember { mutableStateOf<LoanRecord?>(null) }
    var recordToDelete by remember { mutableStateOf<LoanRecord?>(null) }
    var showOfficerDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }

    fun shareSpreadsheetCsv() {
        val csv = viewModel.exportToCsv()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "School Library Circulation Sheet.csv")
            putExtra(Intent.EXTRA_TEXT, csv)
        }
        val chooser = Intent.createChooser(intent, "Export Spreadsheet CSV")
        context.startActivity(chooser)
    }

    fun copyCsvToClipboard() {
        val csv = viewModel.exportToCsv()
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Library Spreadsheet CSV", csv)
        clipboard.setPrimaryClip(clip)
        coroutineScope.launch {
            snackbarHostState.showSnackbar(
                message = "Spreadsheet CSV copied to clipboard!",
                duration = SnackbarDuration.Short
            )
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Teal40),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalLibrary,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.size(10.dp))
                        Column {
                            Text(
                                text = "Library Sheet",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Book Borrow & Return Ledger",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                actions = {
                    // Sort button & menu
                    IconButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier.testTag("sort_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.Sort,
                            contentDescription = "Sort records"
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        SortOption.values().forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = option.displayName,
                                        fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                        color = if (sortOption == option) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    viewModel.sortOption.value = option
                                    showSortMenu = false
                                }
                            )
                        }
                    }

                    // Share CSV button
                    IconButton(
                        onClick = { shareSpreadsheetCsv() },
                        modifier = Modifier.testTag("share_csv_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Export CSV to Google Sheets/Excel"
                        )
                    }

                    // Overflow Menu
                    IconButton(
                        onClick = { showOverflowMenu = true },
                        modifier = Modifier.testTag("overflow_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options"
                        )
                    }

                    DropdownMenu(
                        expanded = showOverflowMenu,
                        onDismissRequest = { showOverflowMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Copy CSV to Clipboard") },
                            leadingIcon = {
                                Icon(Icons.Default.FileDownload, contentDescription = null)
                            },
                            onClick = {
                                showOverflowMenu = false
                                copyCsvToClipboard()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Change Duty Officer") },
                            onClick = {
                                showOverflowMenu = false
                                showOfficerDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Reset to Sample Data") },
                            leadingIcon = {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                            },
                            onClick = {
                                showOverflowMenu = false
                                showResetConfirm = true
                            }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    recordToEdit = null
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Borrow Book", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_loan_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Stats, Search, Officer bar, View toggle
            SpreadsheetHeaderStats(
                stats = stats,
                currentOfficer = currentOfficer,
                searchQuery = searchQuery,
                onSearchChange = { viewModel.searchQuery.value = it },
                selectedFilter = selectedFilter,
                onFilterSelect = { viewModel.selectedFilter.value = it },
                isSpreadsheetView = isSpreadsheetView,
                onToggleView = { viewModel.isSpreadsheetView.value = !isSpreadsheetView },
                onChangeOfficer = { showOfficerDialog = true }
            )

            // Content Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (isSpreadsheetView) {
                    SpreadsheetTableView(
                        records = records,
                        onSelectRecord = { recordToInspect = it },
                        onReturnClick = { recordToReturn = it },
                        onEditClick = { recordToEdit = it },
                        onDeleteClick = { recordToDelete = it }
                    )
                } else {
                    CirculationCardView(
                        records = records,
                        onSelectRecord = { recordToInspect = it },
                        onReturnClick = { recordToReturn = it },
                        onEditClick = { recordToEdit = it },
                        onDeleteClick = { recordToDelete = it }
                    )
                }
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog || recordToEdit != null) {
        AddEditRecordDialog(
            recordToEdit = recordToEdit,
            defaultOfficer = currentOfficer,
            knownOfficers = viewModel.defaultOfficers,
            onDismiss = {
                showAddDialog = false
                recordToEdit = null
            },
            onConfirm = { bId, bTitle, sId, sName, sGrade, officer, bDate, dDate, notes ->
                if (recordToEdit == null) {
                    viewModel.addRecord(
                        bookId = bId,
                        bookTitle = bTitle,
                        borrowerId = sId,
                        borrowerName = sName,
                        borrowerGrade = sGrade,
                        borrowOfficer = officer,
                        borrowDate = bDate,
                        dueDate = dDate,
                        notes = notes
                    )
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Book loan recorded successfully!")
                    }
                } else {
                    val updated = recordToEdit!!.copy(
                        bookId = bId,
                        bookTitle = bTitle,
                        borrowerId = sId,
                        borrowerName = sName,
                        borrowerGrade = sGrade,
                        borrowOfficer = officer,
                        borrowDate = bDate,
                        dueDate = dDate,
                        notes = notes
                    )
                    viewModel.updateRecord(updated)
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Record updated!")
                    }
                }
                showAddDialog = false
                recordToEdit = null
            }
        )
    }

    // Return Book Dialog
    recordToReturn?.let { record ->
        ReturnBookDialog(
            record = record,
            defaultOfficer = currentOfficer,
            knownOfficers = viewModel.defaultOfficers,
            onDismiss = { recordToReturn = null },
            onConfirm = { officer, rDate, notes ->
                viewModel.markReturned(
                    id = record.id,
                    returnOfficer = officer,
                    returnDate = rDate,
                    notes = notes
                )
                recordToReturn = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Book marked as returned!")
                }
            }
        )
    }

    // Inspect Row Details Dialog
    recordToInspect?.let { record ->
        RecordDetailDialog(
            record = record,
            onDismiss = { recordToInspect = null },
            onReturnClick = {
                recordToReturn = record
            },
            onEditClick = {
                recordToEdit = record
            },
            onDeleteClick = {
                recordToDelete = record
            }
        )
    }

    // Change Officer Dialog
    if (showOfficerDialog) {
        ChangeOfficerDialog(
            currentOfficer = currentOfficer,
            knownOfficers = viewModel.defaultOfficers,
            onDismiss = { showOfficerDialog = false },
            onConfirm = { newOfficer ->
                viewModel.currentOfficer.value = newOfficer
                showOfficerDialog = false
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Active officer set to $newOfficer")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("Delete Loan Record?") },
            text = {
                Text("Are you sure you want to permanently delete row #${record.id} (${record.bookTitle} borrowed by ${record.borrowerName}) from the spreadsheet?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteRecord(record)
                        recordToDelete = null
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Row deleted from spreadsheet")
                        }
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Reset Confirmation Dialog
    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Sample Records?") },
            text = {
                Text("This will replace current entries with standard school library sample data.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetData()
                        showResetConfirm = false
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Reset to default sample library records")
                        }
                    }
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
