package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Forest / Library Teal palette
val Teal80 = Color(0xFFA2DFD3)
val TealGrey80 = Color(0xFFBCCBC7)
val Amber80 = Color(0xFFFFD59E)

val Teal40 = Color(0xFF136A5B)
val TealGrey40 = Color(0xFF4C635E)
val Amber40 = Color(0xFF8B5000)

val SurfaceLight = Color(0xFFF7F9F8)
val SurfaceDark = Color(0xFF111615)

val StatusBorrowedBg = Color(0xFFFFF3E0)
val StatusBorrowedText = Color(0xFFE65100)
val StatusReturnedBg = Color(0xFFE8F5E9)
val StatusReturnedText = Color(0xFF2E7D32)
val StatusOverdueBg = Color(0xFFFFEBEE)
val StatusOverdueText = Color(0xFFC62828)

val SheetHeaderBg = Color(0xFFE6EFEA)
val SheetBorder = Color(0xFFD6E2DC)
val SheetZebraBg = Color(0xFFFAFCFA)

