package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.LoanRecord
import com.example.data.LoanRepository
import com.example.data.LoanStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FilterStatus(val title: String) {
    ALL("All Rows"),
    BORROWED("Borrowed"),
    OVERDUE("Overdue"),
    RETURNED("Returned")
}

enum class SortOption(val displayName: String) {
    NEWEST("Newest First"),
    OLDEST("Oldest First"),
    DUE_DATE("Due Date"),
    BORROWER("Borrower Name"),
    BOOK_TITLE("Book Title")
}

data class LibraryStats(
    val total: Int = 0,
    val borrowed: Int = 0,
    val overdue: Int = 0,
    val returned: Int = 0
)

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: LoanRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = LoanRepository(db.loanRecordDao())
        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    val rawRecords: StateFlow<List<LoanRecord>> = repository.allRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val searchQuery = MutableStateFlow("")
    val selectedFilter = MutableStateFlow(FilterStatus.ALL)
    val sortOption = MutableStateFlow(SortOption.NEWEST)
    val isSpreadsheetView = MutableStateFlow(true) // Defaults to Spreadsheet Table view!
    val currentOfficer = MutableStateFlow("Mrs. Sarah Jenkins")

    private val todayString: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    val filteredRecords: StateFlow<List<LoanRecord>> = combine(
        rawRecords,
        searchQuery,
        selectedFilter,
        sortOption
    ) { records, query, filter, sort ->
        val trimmedQuery = query.trim().lowercase()

        val matching = records.filter { record ->
            val status = record.getEffectiveStatus(todayString)

            val matchesFilter = when (filter) {
                FilterStatus.ALL -> true
                FilterStatus.BORROWED -> status == LoanStatus.BORROWED
                FilterStatus.OVERDUE -> status == LoanStatus.OVERDUE
                FilterStatus.RETURNED -> status == LoanStatus.RETURNED
            }

            if (!matchesFilter) return@filter false

            if (trimmedQuery.isEmpty()) return@filter true

            record.bookTitle.lowercase().contains(trimmedQuery) ||
                record.bookId.lowercase().contains(trimmedQuery) ||
                record.borrowerName.lowercase().contains(trimmedQuery) ||
                record.borrowerId.lowercase().contains(trimmedQuery) ||
                record.borrowerGrade.lowercase().contains(trimmedQuery) ||
                record.borrowOfficer.lowercase().contains(trimmedQuery) ||
                (record.returnOfficer?.lowercase()?.contains(trimmedQuery) == true) ||
                record.notes.lowercase().contains(trimmedQuery)
        }

        when (sort) {
            SortOption.NEWEST -> matching.sortedByDescending { it.id }
            SortOption.OLDEST -> matching.sortedBy { it.id }
            SortOption.DUE_DATE -> matching.sortedBy { it.dueDate }
            SortOption.BORROWER -> matching.sortedBy { it.borrowerName.lowercase() }
            SortOption.BOOK_TITLE -> matching.sortedBy { it.bookTitle.lowercase() }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val stats: StateFlow<LibraryStats> = rawRecords.combine(MutableStateFlow(todayString)) { records, today ->
        var borrowed = 0
        var overdue = 0
        var returned = 0
        records.forEach {
            when (it.getEffectiveStatus(today)) {
                LoanStatus.BORROWED -> borrowed++
                LoanStatus.OVERDUE -> overdue++
                LoanStatus.RETURNED -> returned++
            }
        }
        LibraryStats(
            total = records.size,
            borrowed = borrowed,
            overdue = overdue,
            returned = returned
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryStats()
    )

    val defaultOfficers = listOf(
        "Mrs. Sarah Jenkins",
        "Mr. David Aris",
        "Ms. Jessica Taylor",
        "Mr. Kevin Clark",
        "Student Officer Mia"
    )

    fun addRecord(
        bookId: String,
        bookTitle: String,
        borrowerId: String,
        borrowerName: String,
        borrowerGrade: String,
        borrowOfficer: String,
        borrowDate: String,
        dueDate: String,
        notes: String
    ) {
        viewModelScope.launch {
            val record = LoanRecord(
                bookId = bookId.trim(),
                bookTitle = bookTitle.trim(),
                borrowerId = borrowerId.trim(),
                borrowerName = borrowerName.trim(),
                borrowerGrade = borrowerGrade.trim(),
                borrowOfficer = borrowOfficer.trim(),
                borrowDate = borrowDate.trim(),
                dueDate = dueDate.trim(),
                notes = notes.trim(),
                isReturned = false
            )
            repository.insertRecord(record)
            if (borrowOfficer.isNotBlank()) {
                currentOfficer.value = borrowOfficer.trim()
            }
        }
    }

    fun updateRecord(record: LoanRecord) {
        viewModelScope.launch {
            repository.updateRecord(record)
        }
    }

    fun deleteRecord(record: LoanRecord) {
        viewModelScope.launch {
            repository.deleteRecord(record)
        }
    }

    fun markReturned(id: Long, returnOfficer: String, returnDate: String, notes: String) {
        viewModelScope.launch {
            repository.markAsReturned(id, returnOfficer, returnDate, notes)
            if (returnOfficer.isNotBlank()) {
                currentOfficer.value = returnOfficer.trim()
            }
        }
    }

    fun resetData() {
        viewModelScope.launch {
            repository.resetToDefaultSampleData()
        }
    }

    fun exportToCsv(): String {
        val records = rawRecords.value
        val sb = StringBuilder()
        // CSV Header
        sb.append("Row,Book ID,Book Title,Borrower ID,Borrower Name,Grade/Class,Borrow Date,Due Date,Borrow Officer,Status,Return Date,Return Officer,Notes\n")
        records.forEachIndexed { index, r ->
            val status = r.getEffectiveStatus(todayString).label
            val safeBookTitle = "\"" + r.bookTitle.replace("\"", "\"\"") + "\""
            val safeBorrowerName = "\"" + r.borrowerName.replace("\"", "\"\"") + "\""
            val safeNotes = "\"" + r.notes.replace("\"", "\"\"") + "\""
            val safeBorrowOfficer = "\"" + r.borrowOfficer.replace("\"", "\"\"") + "\""
            val safeReturnOfficer = "\"" + (r.returnOfficer ?: "").replace("\"", "\"\"") + "\""
            val safeGrade = "\"" + r.borrowerGrade.replace("\"", "\"\"") + "\""

            sb.append("${index + 1},${r.bookId},$safeBookTitle,${r.borrowerId},$safeBorrowerName,$safeGrade,${r.borrowDate},${r.dueDate},$safeBorrowOfficer,$status,${r.returnDate ?: ""},$safeReturnOfficer,$safeNotes\n")
        }
        return sb.toString()
    }
}
