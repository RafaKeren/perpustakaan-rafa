package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LoanRecord
import com.example.ui.theme.StatusReturnedBg
import com.example.ui.theme.StatusReturnedText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReturnBookDialog(
    record: LoanRecord,
    defaultOfficer: String,
    knownOfficers: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (officer: String, returnDate: String, notes: String) -> Unit
) {
    val todayDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    var returnOfficer by remember {
        mutableStateOf(defaultOfficer.ifBlank { "Mrs. Sarah Jenkins" })
    }
    var returnDate by remember { mutableStateOf(todayDate) }
    var notes by remember { mutableStateOf("Returned in good condition") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AssignmentTurnedIn,
                    contentDescription = null,
                    tint = StatusReturnedText
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Process Book Return",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Summary of Loan
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = record.bookTitle,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Code: ${record.bookId}  •  Borrower: ${record.borrowerName} (${record.borrowerId})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Issued on ${record.borrowDate} by ${record.borrowOfficer}  (Due: ${record.dueDate})",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Text(
                    text = "RECEIVING OFFICER",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = returnOfficer,
                    onValueChange = { returnOfficer = it },
                    label = { Text("Officer in Charge *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_return_officer")
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    knownOfficers.forEach { officer ->
                        FilterChip(
                            selected = returnOfficer.trim().equals(officer.trim(), ignoreCase = true),
                            onClick = { returnOfficer = officer },
                            label = { Text(officer, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = returnDate,
                    onValueChange = { returnDate = it },
                    label = { Text("Return Date") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_return_date")
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Return Condition / Notes") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("input_return_condition")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (returnOfficer.isBlank()) {
                        errorMessage = "Please enter the receiving officer's name."
                    } else {
                        onConfirm(returnOfficer.trim(), returnDate.trim(), notes.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StatusReturnedText),
                modifier = Modifier.testTag("confirm_return_button")
            ) {
                Text("Confirm Return")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
