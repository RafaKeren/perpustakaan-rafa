package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class LoanRepository(private val dao: LoanRecordDao) {

    val allRecords: Flow<List<LoanRecord>> = dao.getAllRecords()

    suspend fun insertRecord(record: LoanRecord): Long {
        return dao.insertRecord(record)
    }

    suspend fun updateRecord(record: LoanRecord) {
        dao.updateRecord(record)
    }

    suspend fun deleteRecord(record: LoanRecord) {
        dao.deleteRecord(record)
    }

    suspend fun markAsReturned(id: Long, returnOfficer: String, returnDate: String, additionalNotes: String = "") {
        val record = dao.getRecordById(id) ?: return
        val updatedNotes = if (additionalNotes.isNotBlank()) {
            if (record.notes.isBlank()) additionalNotes else "${record.notes} | $additionalNotes"
        } else {
            record.notes
        }
        val updated = record.copy(
            isReturned = true,
            returnOfficer = returnOfficer.trim(),
            returnDate = returnDate.trim(),
            notes = updatedNotes
        )
        dao.updateRecord(updated)
    }

    suspend fun checkAndSeedInitialData() {
        if (dao.getCount() == 0) {
            seedSampleRecords()
        }
    }

    suspend fun resetToDefaultSampleData() {
        dao.deleteAll()
        seedSampleRecords()
    }

    private suspend fun seedSampleRecords() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()

        // Helper to format date offset from today
        fun getDateString(dayOffset: Int): String {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, dayOffset)
            return dateFormat.format(c.time)
        }

        val samples = listOf(
            LoanRecord(
                bookId = "BK-1001",
                bookTitle = "To Kill a Mockingbird",
                borrowerId = "STD-2024-042",
                borrowerName = "Maya Lin",
                borrowerGrade = "Grade 10-A",
                borrowOfficer = "Mrs. Sarah Jenkins",
                borrowDate = getDateString(-4),
                dueDate = getDateString(10),
                returnDate = null,
                returnOfficer = null,
                isReturned = false,
                notes = "English Lit class reading"
            ),
            LoanRecord(
                bookId = "BK-2045",
                bookTitle = "Fundamentals of Physics (Vol 1)",
                borrowerId = "STD-2024-118",
                borrowerName = "Liam Henderson",
                borrowerGrade = "Grade 11-B",
                borrowOfficer = "Mr. David Aris",
                borrowDate = getDateString(-16),
                dueDate = getDateString(-2), // Overdue!
                returnDate = null,
                returnOfficer = null,
                isReturned = false,
                notes = "Physics Olympiad preparation"
            ),
            LoanRecord(
                bookId = "BK-3310",
                bookTitle = "The Great Gatsby",
                borrowerId = "STD-2024-009",
                borrowerName = "Sophia Rodriguez",
                borrowerGrade = "Grade 12-A",
                borrowOfficer = "Mrs. Sarah Jenkins",
                borrowDate = getDateString(-10),
                dueDate = getDateString(4),
                returnDate = getDateString(-1),
                returnOfficer = "Ms. Jessica Taylor",
                isReturned = true,
                notes = "Returned early in pristine condition"
            ),
            LoanRecord(
                bookId = "BK-4102",
                bookTitle = "Introduction to Algorithms",
                borrowerId = "TCH-081",
                borrowerName = "Mr. Alan Becker",
                borrowerGrade = "CS Faculty",
                borrowOfficer = "Mr. Kevin Clark",
                borrowDate = getDateString(-2),
                dueDate = getDateString(26),
                returnDate = null,
                returnOfficer = null,
                isReturned = false,
                notes = "Curriculum planning reference"
            ),
            LoanRecord(
                bookId = "BK-5520",
                bookTitle = "Lord of the Flies",
                borrowerId = "STD-2024-205",
                borrowerName = "Lucas Wright",
                borrowerGrade = "Grade 9-C",
                borrowOfficer = "Ms. Jessica Taylor",
                borrowDate = getDateString(-18),
                dueDate = getDateString(-4), // Overdue!
                returnDate = null,
                returnOfficer = null,
                isReturned = false,
                notes = "First reminder notice sent"
            ),
            LoanRecord(
                bookId = "BK-6014",
                bookTitle = "Biology: Exploring Life",
                borrowerId = "STD-2024-073",
                borrowerName = "Emma Watson",
                borrowerGrade = "Grade 10-B",
                borrowOfficer = "Mr. David Aris",
                borrowDate = getDateString(-14),
                dueDate = getDateString(0),
                returnDate = getDateString(0),
                returnOfficer = "Mrs. Sarah Jenkins",
                isReturned = true,
                notes = "Returned on due date"
            ),
            LoanRecord(
                bookId = "BK-7128",
                bookTitle = "World History: The Modern Era",
                borrowerId = "STD-2024-156",
                borrowerName = "Noah Tanaka",
                borrowerGrade = "Grade 11-A",
                borrowOfficer = "Mrs. Sarah Jenkins",
                borrowDate = getDateString(-1),
                dueDate = getDateString(13),
                returnDate = null,
                returnOfficer = null,
                isReturned = false,
                notes = "Chapter 4 term paper"
            )
        )

        dao.insertAll(samples)
    }
}
