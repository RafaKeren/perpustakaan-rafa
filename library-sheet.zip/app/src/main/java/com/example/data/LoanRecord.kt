package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "loan_records")
data class LoanRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val bookId: String,
    val bookTitle: String,
    val borrowerId: String,
    val borrowerName: String,
    val borrowerGrade: String = "",
    val borrowOfficer: String,
    val borrowDate: String,
    val dueDate: String,
    val returnDate: String? = null,
    val returnOfficer: String? = null,
    val isReturned: Boolean = false,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getEffectiveStatus(todayString: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())): LoanStatus {
        return when {
            isReturned -> LoanStatus.RETURNED
            dueDate < todayString -> LoanStatus.OVERDUE
            else -> LoanStatus.BORROWED
        }
    }
}

enum class LoanStatus(val label: String) {
    BORROWED("Borrowed"),
    RETURNED("Returned"),
    OVERDUE("Overdue")
}
