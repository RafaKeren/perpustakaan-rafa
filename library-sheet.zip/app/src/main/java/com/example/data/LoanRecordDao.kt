package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanRecordDao {
    @Query("SELECT * FROM loan_records ORDER BY id DESC")
    fun getAllRecords(): Flow<List<LoanRecord>>

    @Query("SELECT * FROM loan_records WHERE id = :id")
    suspend fun getRecordById(id: Long): LoanRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: LoanRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<LoanRecord>)

    @Update
    suspend fun updateRecord(record: LoanRecord)

    @Delete
    suspend fun deleteRecord(record: LoanRecord)

    @Query("DELETE FROM loan_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM loan_records")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM loan_records")
    suspend fun getCount(): Int
}
